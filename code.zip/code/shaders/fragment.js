export const fragmentShaderSrc = `      		
    precision mediump float;   	
    uniform vec4 uColor;
	void main () {   	
		gl_FragColor = vec4(uColor);
	}                            
`;